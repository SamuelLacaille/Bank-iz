/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bankiz.model;

/**
 *
 * @author Admin
 */
public class Client {
     private int idClient;
     private String nomClient;
     private String prenomClient;
     private String emailClient;
     private int ageClient;
     private String situationFamilialeClient;
     private String situationProClient;
     private int revenusClient;
     private int depensesClient;
     private String souscriptionsClient;

    public Client(int idClient, String nomClient, String prenomClient,String emailClient, int ageClient, String situationFamilialeClient, String situationProClient, int revenusClient, int depensesClient, String souscriptionsClient){
        this.idClient = idClient;
        this.nomClient = nomClient;
        this.prenomClient = prenomClient;
        this.emailClient = emailClient;
        this.ageClient = ageClient;
        this.situationFamilialeClient = situationFamilialeClient;
        this.situationProClient = situationProClient;
        this.revenusClient = revenusClient;
        this.depensesClient = depensesClient;
        this.souscriptionsClient = souscriptionsClient;
    }

    public int getIdClient() {
        return idClient;
    }

    public String getNomClient() {
        return nomClient;
    }

    public String getPrenomClient() {
        return prenomClient;
    }

    public String getEmailClient() {
        return emailClient;
    }

    public int getAgeClient() {
        return ageClient;
    }

    public String getSituationFamilialeClient() {
        return situationFamilialeClient;
    }

    public String getSituationProClient() {
        return situationProClient;
    }

    public int getRevenusClient() {
        return revenusClient;
    }

    public int getDepensesClient() {
        return depensesClient;
    }

    public String getSouscriptionsClient() {
        return souscriptionsClient;
    }
}
