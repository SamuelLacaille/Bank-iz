/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bankiz.model;

/**
 *
 * @author Admin
 */
public class User {
     private int idUser;
     private String nomUser;
     private String emailUser;
       private String mdpUser;
    

    public void setNomUser(String nomUser) {
        this.nomUser = nomUser;
    }
   

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public void setMdpUser(String mdpUser) {
        this.mdpUser = mdpUser;
    }

    public void setEmailUser(String emailUser) {
        this.emailUser = emailUser;
    }

    public int getIdUser() {
        return idUser;
    }

    public String getNomUser() {
        return nomUser;
    }

    public String getMdpUser() {
        return mdpUser;
    }

    public String getEmailUser() {
        return emailUser;
    }
   
}
