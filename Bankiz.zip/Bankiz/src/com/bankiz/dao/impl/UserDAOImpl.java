/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bankiz.dao.impl;


import java.sql.Connection;
import java.sql.PreparedStatement;
import com.bankiz.util.DBUtil;

import com.bankiz.model.User;
import com.bankiz.dao.UserDao;
import java.sql.SQLException;
import java.sql.ResultSet;


/**
 *
 * @author Admin
 */
public class UserDAOImpl implements UserDao{
    
   
    @Override
    public User getUser(Integer idUser){
        User user = null;
        String SQL = "SELECT * FROM user WHERE idUser=?";
        
        try(Connection connection = DBUtil.getConnection(); PreparedStatement ps = connection.prepareStatement(SQL)){
            
            ps.setInt(1, idUser);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                int userId = rs.getInt("idUser");
                String userNom = rs.getString("nomUser");
                String userEmail = rs.getString("emailUser");
                String userMdp = rs.getString("mdpUser");
                
                
                user = new User();
                user.setIdUser(userId);
                user.setNomUser(userNom);
                user.setEmailUser(userEmail);
                user.setMdpUser(userMdp);
            }
            
        } catch (SQLException ex) {
         
        }
        return user;
        
    }

    @Override
    public User getPrenomUser(Integer idUser) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
