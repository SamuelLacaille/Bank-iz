/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bankiz.dao;


import com.bankiz.model.User;
/**
 *
 * @author Admin
 */
public interface UserDao {
    // connection
     public abstract User getUser(Integer idUser);
     
     // recuperer nom du user
     public abstract User getPrenomUser(Integer idUser);
}
